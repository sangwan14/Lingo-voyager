module.exports = {
  images: {
    domains: ['ssl.gstatic.com'],
  },
}